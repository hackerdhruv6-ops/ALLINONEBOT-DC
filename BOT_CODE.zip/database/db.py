import aiosqlite
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'generator.db')

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute('''
            CREATE TABLE IF NOT EXISTS services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_name TEXT NOT NULL,
                tier TEXT NOT NULL,
                service_type TEXT DEFAULT 'account',
                UNIQUE(service_name, tier)
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS stock (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE CASCADE
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS cooldowns (
                user_id INTEGER NOT NULL,
                tier TEXT NOT NULL,
                last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, tier)
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                service_name TEXT NOT NULL,
                tier TEXT NOT NULL,
                generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        await db.execute('''
            CREATE TABLE IF NOT EXISTS bans (
                user_id INTEGER PRIMARY KEY,
                reason TEXT,
                expires_at TIMESTAMP -- NULL means permanent
            )
        ''')

        await db.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        ''')

        await db.execute('''
            CREATE TABLE IF NOT EXISTS requirement_monitor (
                user_id INTEGER PRIMARY KEY
            )
        ''')

        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('premium_enabled', '1')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('invite_system_enabled', '1')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('logs_channel_id', '')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('restock_channel_id', '')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('vouch_channel_id', '')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('fgen_cooldown', '60')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('pgen_cooldown', '30')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('bgen_cooldown', '30')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('restock_ping_enabled', '0')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('restock_role_id', '')")

        await db.execute('''
            CREATE TABLE IF NOT EXISTS vouch_tracking (
                user_id INTEGER PRIMARY KEY,
                last_service TEXT,
                last_tier TEXT,
                generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                vouched INTEGER DEFAULT 0 -- 0: Pending, 1: Vouched
            )
        ''')

        try:
            await db.execute("ALTER TABLE services ADD COLUMN service_type TEXT DEFAULT 'account'")
        except:
            pass

        await db.execute("UPDATE services SET tier = 'premium' WHERE tier = 'vip'")
        await db.execute("UPDATE cooldowns SET tier = 'premium' WHERE tier = 'vip'")
        await db.execute("UPDATE logs SET tier = 'premium' WHERE tier = 'vip'")
        
        await db.commit()

async def ban_user(user_id: int, reason: str, duration_seconds: int = None):
    async with aiosqlite.connect(DB_PATH) as db:
        expires_at = None
        if duration_seconds:
            await db.execute("INSERT OR REPLACE INTO bans (user_id, reason, expires_at) VALUES (?, ?, datetime('now', ? || ' seconds'))", (user_id, reason, duration_seconds))
        else:
            await db.execute("INSERT OR REPLACE INTO bans (user_id, reason, expires_at) VALUES (?, ?, NULL)", (user_id, reason))
        await db.commit()

async def unban_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM bans WHERE user_id = ?", (user_id,))
        await db.commit()

async def is_banned(user_id: int) -> tuple[bool, str | None]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT reason, expires_at FROM bans WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        if not row:
            return False, None
        
        reason, expires_at = row
        if expires_at:
            cursor = await db.execute("SELECT datetime('now') > ?", (expires_at,))
            expired = (await cursor.fetchone())[0]
            if expired:
                await unban_user(user_id)
                return False, None
        
        return True, reason

async def track_generation(user_id: int, service: str, tier: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT OR REPLACE INTO vouch_tracking (user_id, last_service, last_tier, generated_at, vouched)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP, 0)
        ''', (user_id, service, tier))
        await db.commit()

async def mark_vouched(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE vouch_tracking SET vouched = 1 WHERE user_id = ?", (user_id,))
        await db.commit()

async def delete_vouch_tracking(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM vouch_tracking WHERE user_id = ?", (user_id,))
        await db.commit()

async def get_pending_vouches() -> list:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('''
            SELECT user_id, last_service, last_tier 
            FROM vouch_tracking 
            WHERE vouched = 0 AND strftime('%s', 'now') - strftime('%s', generated_at) > 300
        ''')
        return await cursor.fetchall()

async def create_service(service_name: str, tier: str, service_type: str = 'account') -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "INSERT INTO services (service_name, tier, service_type) VALUES (?, ?, ?)",
                (service_name.lower(), tier.lower(), service_type.lower())
            )
            await db.commit()
            return True
        except aiosqlite.IntegrityError:
            return False

async def delete_service(service_name: str, tier: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "DELETE FROM services WHERE service_name = ? AND tier = ?",
            (service_name.lower(), tier.lower())
        )
        await db.commit()
        return cursor.rowcount > 0

async def get_services(tier: str) -> list[tuple[str, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT service_name, service_type FROM services WHERE tier = ?", 
            (tier.lower(),)
        ) as cursor:
            rows = await cursor.fetchall()
            return [(row[0], row[1]) for row in rows]

async def get_service_type(service_name: str, tier: str) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT service_type FROM services WHERE service_name = ? AND tier = ?",
            (service_name.lower(), tier.lower())
        )
        row = await cursor.fetchone()
        return row[0] if row else 'account'

async def add_stock(service_name: str, tier: str, items: list[str]) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT id FROM services WHERE service_name = ? AND tier = ?",
            (service_name.lower(), tier.lower())
        )
        service = await cursor.fetchone()
        if not service: return 0
        service_id = service[0]
        values = [(service_id, item) for item in items]
        await db.executemany("INSERT INTO stock (service_id, content) VALUES (?, ?)", values)
        await db.commit()
        return len(items)

async def overwrite_stock(service_name: str, tier: str, items: list[str]) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT id FROM services WHERE service_name = ? AND tier = ?",
            (service_name.lower(), tier.lower())
        )
        service = await cursor.fetchone()
        if not service: return 0
        service_id = service[0]
        
        await db.execute("DELETE FROM stock WHERE service_id = ?", (service_id,))
        
        if items:
            values = [(service_id, item) for item in items if item.strip()]
            await db.executemany("INSERT INTO stock (service_id, content) VALUES (?, ?)", values)
            
        await db.commit()
        return len(items)

async def get_raw_stock(service_name: str, tier: str) -> list[str]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('''
            SELECT stock.content 
            FROM stock 
            JOIN services ON stock.service_id = services.id 
            WHERE services.service_name = ? AND services.tier = ?
        ''', (service_name.lower(), tier.lower()))
        rows = await cursor.fetchall()
        return [row[0] for row in rows]

async def get_all_stock_counts() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('''
            SELECT services.tier, services.service_name, COUNT(stock.id)
            FROM services
            LEFT JOIN stock ON services.id = stock.service_id
            GROUP BY services.id
        ''')
        rows = await cursor.fetchall()
        result = {"free": {}, "premium": {}, "booster": {}}
        for tier, name, count in rows:
            if tier in result:
                result[tier][name] = count
        return result

async def generate_item(service_name: str, tier: str) -> tuple[str | None, str]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT id, service_type FROM services WHERE service_name = ? AND tier = ?",
            (service_name.lower(), tier.lower())
        )
        service = await cursor.fetchone()
        if not service: return None, 'account'
        service_id, service_type = service
        cursor = await db.execute("SELECT id, content FROM stock WHERE service_id = ? LIMIT 1", (service_id,))
        item = await cursor.fetchone()
        if not item: return None, service_type
        await db.execute("DELETE FROM stock WHERE id = ?", (item[0],))
        await db.commit()
        return item[1], service_type

async def log_generation(user_id: int, service_name: str, tier: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO logs (user_id, service_name, tier) VALUES (?, ?, ?)",
            (user_id, service_name.lower(), tier.lower())
        )
        await db.commit()

async def check_cooldown(user_id: int, tier: str, cooldown_seconds: int) -> tuple[bool, int]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT strftime('%s', 'now') - strftime('%s', last_used) FROM cooldowns WHERE user_id = ? AND tier = ?",
            (user_id, tier.lower())
        )
        row = await cursor.fetchone()
        if row and row[0] is not None:
            elapsed = int(row[0])
            if elapsed < cooldown_seconds:
                return False, cooldown_seconds - elapsed
        return True, 0

async def set_cooldown(user_id: int, tier: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT OR REPLACE INTO cooldowns (user_id, tier, last_used)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        ''', (user_id, tier.lower()))
        await db.commit()

async def get_setting(key: str, default: str = None) -> str | None:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cursor.fetchone()
        return row[0] if row else default

async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
        await db.commit()

async def get_setup_status() -> bool:
    """Checks if both gen channels and role IDs are configured."""
    keys = [
        "fgen_channel_id", "fgen_role_id",
        "pgen_channel_id", "pgen_role_id",
        "bgen_channel_id", "bgen_role_id",
        "vouch_channel_id"
    ]
    for key in keys:
        val = await get_setting(key)
        if not val:
            return False
    return True

async def ban_user(user_id: int, reason: str, duration_seconds: int = None):
    expires_at = None
    if duration_seconds:
        expires_at = f"datetime('now', '+{duration_seconds} seconds')"
    
    async with aiosqlite.connect(DB_PATH) as db:
        if expires_at:
            await db.execute(f"INSERT OR REPLACE INTO bans (user_id, reason, expires_at) VALUES (?, ?, {expires_at})", (user_id, reason))
        else:
            await db.execute("INSERT OR REPLACE INTO bans (user_id, reason, expires_at) VALUES (?, ?, NULL)", (user_id, reason))
        await db.commit()

async def is_monitored(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM requirement_monitor WHERE user_id = ?", (user_id,)) as cursor:
            return await cursor.fetchone() is not None

async def add_monitor(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO requirement_monitor (user_id) VALUES (?)", (user_id,))
        await db.commit()

async def remove_monitor(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM requirement_monitor WHERE user_id = ?", (user_id,))
        await db.commit()

async def get_all_monitored() -> list[int]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT user_id FROM requirement_monitor") as cursor:
            rows = await cursor.fetchall()
            return [r[0] for r in rows]

async def unban_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM bans WHERE user_id = ?", (user_id,))
        await db.commit()

async def is_banned(user_id: int) -> tuple[bool, str | None]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT reason, expires_at FROM bans WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if not row: return False, None
            
            reason, expires_at = row
            if expires_at:
                async with db.execute("SELECT 1 WHERE datetime(?) < datetime('now')", (expires_at,)) as exp_cursor:
                    if await exp_cursor.fetchone():
                        await unban_user(user_id)
                        return False, None
            
            return True, reason

"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
