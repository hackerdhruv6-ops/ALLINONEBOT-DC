import discord
from discord import ui
from discord.ext import commands
import time
from datetime import datetime, timedelta
from database import db
from utils.emojis import emoji as Emoji

class GeneralCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def get_uptime(self) -> str:
        # main.py sets self.bot.start_time as a datetime object
        uptime_delta = datetime.now() - self.bot.start_time
        d = uptime_delta.days
        h, rem = divmod(uptime_delta.seconds, 3600)
        m, s = divmod(rem, 60)
        parts = []
        if d: parts.append(f"{d}d")
        if h: parts.append(f"{h}h")
        if m: parts.append(f"{m}m")
        parts.append(f"{s}s")
        return " ".join(parts)

    def build_stats_view(self) -> ui.LayoutView:
        import psutil
        import platform
        import os
        process = psutil.Process(os.getpid())
        mem_pct = process.memory_percent()
        cpu_pct = process.cpu_percent(interval=None)

        guilds = len(self.bot.guilds)
        users = sum(g.member_count or 0 for g in self.bot.guilds)
        cmds = len([c for c in self.bot.walk_commands()])
        latency = round(self.bot.latency * 1000)
        uptime = self.get_uptime()
        py_ver = platform.python_version()
        dpy_ver = discord.__version__
        os_name = f"{platform.system()} {platform.release()}"

        host = os.environ.get("HOST_NAME", "FeroX Dedicated Node")

        view = ui.LayoutView()
        container = ui.Container(accent_color=None)

        container.add_item(ui.TextDisplay(f"# {Emoji.stats} System Statistics"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        container.add_item(ui.TextDisplay(
            "## Engine\n"
            f"-# Core Logic\n**FeroX Gen System**\n"
            f"-# Uptime\n`{uptime}`\n"
            f"-# Commands\n**{cmds}** Modules\n"
            f"-# Connection Latency\n`{latency}ms WebSocket`"
        ))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        container.add_item(ui.TextDisplay(
            "## Network\n"
            f"-# Servers\n**{guilds:,}** Guilds\n"
            f"-# Authorized Connections\n**{users:,}** Users"
        ))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        container.add_item(ui.TextDisplay(
            "## System Status\n"
            f"-# Runtime\n`Python {py_ver}` | `discord.py {dpy_ver}`\n"
            f"-# Core Allocation\n`RAM Usage: {mem_pct:.2f}%` | `CPU Usage: {cpu_pct:.2f}%`\n"
            f"-# Server Host\n`{host}` | `{os_name}`"
        ))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        refresh_btn = ui.Button(
            label="Refresh Stats",
            style=discord.ButtonStyle.secondary,
            custom_id="stats_refresh"
        )
        action_row = ui.ActionRow(refresh_btn)
        container.add_item(action_row)

        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))

        view.add_item(container)
        return view

    @commands.hybrid_command(name="ping", description="Check the bot's latency protocol")
    async def ping(self, ctx):
        latency = round(self.bot.latency * 1000)
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"# {Emoji.stats} Connection Status"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"**Gateway Latency:** `{latency}ms`\n**Shard Sector:** `{ctx.guild.shard_id if ctx.guild else 0}`"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="stock", description="Check live account availability across all generator sectors")
    async def stock(self, ctx: commands.Context):
        counts = await db.get_all_stock_counts()
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay(f"# {Emoji.stats} Live Stock Inventory"))
        container.add_item(ui.Separator())

        # Free Tier
        free_stock = "\n".join([f"> **{name.title()}**: `{count}`" for name, count in counts['free'].items()]) if counts['free'] else "> *No free services initialized.*"
        container.add_item(ui.TextDisplay(f"### {Emoji.free} Free Gen Stock\n{free_stock}"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        # Booster Tier
        booster_stock = "\n".join([f"> **{name.title()}**: `{count}`" for name, count in counts['booster'].items()]) if counts['booster'] else "> *No booster services initialized.*"
        container.add_item(ui.TextDisplay(f"### {Emoji.booster} Booster Gen Stock\n{booster_stock}"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))

        # Premium Tier
        premium_stock = "\n".join([f"> **{name.title()}**: `{count}`" for name, count in counts['premium'].items()]) if counts['premium'] else "> *No premium services initialized.*"
        container.add_item(ui.TextDisplay(f"### {Emoji.premium} Premium Gen Stock\n{premium_stock}"))
        
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="stats", description="View comprehensive system diagnostics and bot statistics")
    async def stats(self, ctx: commands.Context):
        view = self.build_stats_view()
        await ctx.send(view=view, ephemeral=False)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type == discord.InteractionType.component and "custom_id" in interaction.data:
            if interaction.data.get("custom_id") == "stats_refresh":
                view = self.build_stats_view()
                await interaction.response.edit_message(view=view)

    @commands.hybrid_command(name="cstatus", description="Opt-in/out of automated status/invite monitoring for the Free Gen role")
    async def cstatus(self, ctx):
        req_cog = self.bot.get_cog("RequirementEvents")
        if not req_cog:
            return await ctx.send(f"{Emoji.error} Requirement System Offline.", ephemeral=True)

        is_mon = await db.is_monitored(ctx.author.id)
        
        if is_mon:
            await db.remove_monitor(ctx.author.id)
            
            fgen_role_id = await db.get_setting("fgen_role_id")
            if fgen_role_id:
                try:
                    role = ctx.guild.get_role(int(fgen_role_id))
                    if role and role in ctx.author.roles:
                        await ctx.author.remove_roles(role, reason="Manual Monitor Deactivation")
                except discord.Forbidden:
                    pass
                except Exception:
                    pass

            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.shield} Monitor Status"))
            container.add_item(ui.TextDisplay(f"**Status:** `DEACTIVATED` {Emoji.error}\nYou have opted out of automated monitoring and your access has been revoked."))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            return await ctx.send(view=view, ephemeral=True)

        status_req = await db.get_setting("status_req")
        invite_req_str = await db.get_setting("invite_req")
        invite_req = int(invite_req_str) if invite_req_str and invite_req_str.isdigit() else 0
        
        invite_counts = {}
        if ctx.guild.me.guild_permissions.manage_guild:
            try:
                invites = await ctx.guild.invites()
                for inv in invites:
                    if inv.inviter:
                        invite_counts[inv.inviter.id] = invite_counts.get(inv.inviter.id, 0) + inv.uses
            except: pass

        has_status, has_invites, status_text, user_invites = await req_cog.check_eligibility(
            ctx.author, status_req, invite_req, invite_counts
        )

        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"## {Emoji.shield} Monitor Setup"))

        if has_status and has_invites:
            await db.add_monitor(ctx.author.id)
            
            fgen_role_id = await db.get_setting("fgen_role_id")
            if fgen_role_id:
                try:
                    role = ctx.guild.get_role(int(fgen_role_id))
                    if role:
                        await ctx.author.add_roles(role, reason="Initial Setup Met")
                except discord.Forbidden:
                    view_err = ui.LayoutView()
                    container_err = ui.Container(accent_color=None)
                    container_err.add_item(ui.TextDisplay(f"## {Emoji.warning} Setup Error"))
                    container_err.add_item(ui.TextDisplay(f"I cannot assign the **Free Gen** role directly. Please ensure my bot role is higher than the role I'm trying to assign."))
                    view_err.add_item(container_err)
                    return await ctx.send(view=view_err, ephemeral=True)
                except Exception:
                    pass

            container.add_item(ui.TextDisplay(
                f"**Status:** `ACTIVATED` {Emoji.success}\n"
                f"Setup successful. You have been granted the **Free Gen** role.\n"
                f"Note: If you remove your status or invites, your access will be revoked within 60 seconds."
            ))
        else:
            reasons = []
            if not has_status: reasons.append(f"- Missing `{status_req}` in status (Current: `{status_text}`)")
            if not has_invites: reasons.append(f"- Need `{invite_req}` invites (Currently have `{user_invites}`)")
            
            reasons_text = "\n".join(reasons)
            container.add_item(ui.TextDisplay(
                f"**Status:** `FAILED` {Emoji.error}\n"
                f"Requirements not met:\n{reasons_text}\n\n"
                f"Please fix the above and try again."
            ))

        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(GeneralCommands(bot))
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
