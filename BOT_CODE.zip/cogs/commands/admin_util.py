import discord
from discord import ui
from discord.ext import commands
import config
from utils.emojis import emoji as Emoji
from database import db
from io import BytesIO

class AdminUtility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _is_admin(self, ctx):
        return ctx.author.guild_permissions.administrator

    @commands.hybrid_command(name="uploadstock", description="Bulk upload accounts from a text file")
    @commands.has_permissions(administrator=True)
    async def uploadstock(self, ctx, tier: str, service: str, file: discord.Attachment):
        if tier.lower() not in ["free", "premium", "booster"]:
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.error} Selection Error"))
            container.add_item(ui.TextDisplay(f"The tier **{tier}** is invalid.\n**Valid options:** `free`, `premium`, `booster`"))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)
            return

        if not file.filename.endswith('.txt'):
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.error} File Error"))
            container.add_item(ui.TextDisplay(f"Unsupported file format: `{file.filename}`.\nPlease upload a `.txt` file containing credentials."))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)
            return

        await ctx.defer(ephemeral=True)
        
        try:
            content = await file.read()
            items = content.decode('utf-8').splitlines()
            items = [i.strip() for i in items if i.strip()]
            
            if not items:
                view = ui.LayoutView()
                container = ui.Container(accent_color=None)
                container.add_item(ui.TextDisplay(f"## {Emoji.warning} Import Error"))
                container.add_item(ui.TextDisplay("The uploaded file is empty or contains no valid credentials."))
                container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
                container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
                view.add_item(container)
                await ctx.send(view=view, ephemeral=True)
                return
                
            added = await db.add_stock(service, tier, items)
            
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.success} Bulk Upload Successful"))
            container.add_item(ui.TextDisplay(f"Added **{added}** accounts to **{service.title()}** ({tier.title()})."))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)
        except Exception as e:
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.error} Critical Failure"))
            container.add_item(ui.TextDisplay(f"Failed to process inventory upload: `{str(e)}`"))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)

    @commands.hybrid_command(name="restock", description="Announce a new stock update with a role ping")
    @commands.has_permissions(administrator=True)
    async def restock(self, ctx, tier: str, service: str):
        await ctx.defer()
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        
        header = ui.Section(
            ui.TextDisplay(f"# {Emoji.sparkle} **New Stock Announcement** {Emoji.sparkle}"),
            ui.TextDisplay(f"Our inventory has just been refreshed! Get your accounts now."),
            accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=self.bot.user.display_avatar.url))
        )
        container.add_item(header)
        container.add_item(ui.Separator())
        
        container.add_item(ui.TextDisplay(
            f"### {Emoji.stock} **Restock Details**\n"
            f"> **Service:** {service.title()}\n"
            f"> **Tier:** {tier.title()}\n"
            f"> **Status:** `Online` {Emoji.online}"
        ))
        
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"-# Use `/fgen`, `/pgen`, or `/bgen` to generate.\n-# {Emoji.crown} Developed by FeroX Development"))
        
        view.add_item(container)
        
        ping_role = ctx.guild.get_role(config.RESTOCK_ROLE_ID)
        ping_text = ping_role.mention if ping_role else "@everyone"
        
        await ctx.send(content=ping_text, view=view)

    @commands.hybrid_command(name="setcooldown", description="Update the cooldown for a specific tier")
    @commands.has_permissions(administrator=True)
    async def setcooldown(self, ctx, tier: str, seconds: int):
        tier = tier.lower()
        if tier not in ["free", "premium", "booster"]:
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.error} Selection Error"))
            container.add_item(ui.TextDisplay(f"Tier **{tier}** is invalid.\n**Valid options:** `free`, `premium`, `booster`"))
            container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)
            return

        cooldown_min_str = str(max(1, round(seconds // 60)))

        if tier == "free": 
            await db.set_setting("fgen_cooldown", str(seconds // 60))
        elif tier == "premium": 
            await db.set_setting("pgen_cooldown", str(seconds // 60))
        elif tier == "booster": 
            await db.set_setting("bgen_cooldown", str(seconds // 60))
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"## {Emoji.gear} Synchronized"))
        container.add_item(ui.TextDisplay(f"Set **{tier.title()}** generation cooldown to `{seconds}` seconds (`{seconds // 60}` minutes).\n**Status:** `Committed to DB` {Emoji.success}"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view)

async def setup(bot):
    await bot.add_cog(AdminUtility(bot))
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
