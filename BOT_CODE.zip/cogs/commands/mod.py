import discord
from discord import ui
from discord.ext import commands
from database import db
import config
from utils.emojis import emoji as Emoji
from typing import Optional

class ModerationCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _moderator_check(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            view = ui.LayoutView()
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"## {Emoji.error} Access Denied"))
            container.add_item(ui.TextDisplay("You do not have permission to use moderation commands."))
            view.add_item(container)
            await ctx.send(view=view, ephemeral=True)
            return False
        return True

    @commands.hybrid_command(name="ban", description="Permanently ban a user from the generator")
    async def ban(self, ctx, user: discord.User, *, reason: str = "No reason provided"):
        if not await self._moderator_check(ctx): return
        
        await db.ban_user(user.id, reason)
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"## {Emoji.trash} User Banned"))
        container.add_item(ui.TextDisplay(f"**User:** {user.mention} (`{user.id}`)\n**Reason:** {reason}\n**Type:** Permanent"))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="tempban", description="Temporarily ban a user from the generator")
    async def tempban(self, ctx, user: discord.User, duration_seconds: int, *, reason: str = "No reason provided"):
        if not await self._moderator_check(ctx): return
        
        await db.ban_user(user.id, reason, duration_seconds)
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"## {Emoji.warning} Temporary Ban"))
        container.add_item(ui.TextDisplay(
            f"**User:** {user.mention}\n"
            f"**Duration:** `{duration_seconds}` seconds\n"
            f"**Reason:** {reason}"
        ))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="unban", description="Unban a user from the generator")
    async def unban(self, ctx, user: discord.User):
        if ctx.author.id not in config.OWNER_IDS: return
        
        await db.unban_user(user.id)
        
        view = ui.LayoutView()
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"## {Emoji.success} User Unbanned"))
        container.add_item(ui.TextDisplay(f"Successfully removed generator ban for {user.mention}."))
        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
        view.add_item(container)
        await ctx.send(view=view)

async def setup(bot):
    await bot.add_cog(ModerationCommands(bot))
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
