import discord
from discord import ui
from discord.ext import commands, tasks
from colorama import Fore, Style
from utils.emojis import emoji as Emoji
from database import db
import config
from datetime import datetime

class MessageEvents(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.vouch_checker.start()
    
    def cog_unload(self):
        self.vouch_checker.cancel()

    @tasks.loop(minutes=1)
    async def vouch_checker(self):
        """Checks for expired vouches and auto-bans users"""
        try:
            pending = await db.get_pending_vouches()
            for user_id, service, tier in pending:
                reason = f"Automated Tempban: Failed to vouch for {service} ({tier}) within 5 minutes."
                await db.ban_user(user_id, reason, config.VOUCH_BAN_DURATION)
                                
                await db.delete_vouch_tracking(user_id)

                try:
                    user = self.bot.get_user(user_id) or await self.bot.fetch_user(user_id)
                    if user:
                        view = ui.LayoutView()
                        container = ui.Container(accent_color=None)
                        container.add_item(ui.TextDisplay(f"## {Emoji.lock} Generator Ban Active"))
                        container.add_item(ui.TextDisplay(
                            f"You have been temporarily banned from using the generator.\n"
                            f"**Reason:** Missing vouch for `{service}`.\n"
                            f"**Duration:** `{config.VOUCH_BAN_DURATION}` seconds."
                        ))
                        container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
                        container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
                        view.add_item(container)
                        await user.send(view=view)
                except Exception as e:
                    print(f"Failed to DM banned user {user_id}: {e}")
        except Exception as e:
            print(f"Error in vouch_checker: {e}")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        try:
            if message.author.bot or not message.guild:
                return

            vouch_cid = int(await db.get_setting("vouch_channel_id", getattr(config, "VOUCH_CHANNEL_ID", 1493194221463666788)))
            if message.channel.id == vouch_cid:
                content = message.content.lower()
                if "legit got" in content:

                    await db.mark_vouched(message.author.id)
                    try:
                        await message.add_reaction(Emoji.success)
                    except:
                        pass
                    return

            if self.bot.user.mentioned_in(message) and not message.mention_everyone:
                if len(message.content.strip().split()) == 1:
                    
                    prefix = self.bot.get_guild_prefix(message.guild.id)
                    client_id = self.bot.user.id
                    
                    container = ui.Container(accent_color=None)
                    
                    header_section = ui.Section(
                        ui.TextDisplay(f"# FeroX Development™ {Emoji.ferox_icon}"),
                        ui.TextDisplay("> Premium Generator Solutions"),
                        accessory=ui.Thumbnail(
                            media=discord.UnfurledMediaItem(url=self.bot.user.display_avatar.url),
                            description="FeroX Logo"
                        )
                    )
                    container.add_item(header_section)
                    container.add_item(ui.Separator())
                    
                    info_text = ui.TextDisplay(
                        f"### {Emoji.arrow} **System Information**\n"
                        f"- **Identity:** <@{client_id}>\n"
                        f"- **Owner:** {message.author.mention}\n"
                        f"- **Prefix:** `{prefix}`\n"
                        f"- **Status:** `Operational` {Emoji.success}\n"
                        f"- **Latency:** `{round(self.bot.latency * 1000)}ms`"
                    )
                    container.add_item(info_text)
                    
                    start_text = ui.TextDisplay(
                        f"### {Emoji.gear} **Getting Started**\n"
                        f"- Use `{prefix}help` to view commands.\n"
                        f"- Use `{prefix}stock` to check availability."
                    )
                    container.add_item(start_text)
                    container.add_item(ui.Separator())
                    
                    buttons = ui.ActionRow()
                    buttons.add_item(ui.Button(label="Support Server", url="https://discord.gg/3BXpr66nuT", style=discord.ButtonStyle.link, emoji=Emoji.link))
                    buttons.add_item(ui.Button(label="Invite Me", url=f"https://discord.com/oauth2/authorize?client_id={client_id}", style=discord.ButtonStyle.link, emoji=Emoji.plus))
                    container.add_item(buttons)
                    
                    container.add_item(ui.Separator(spacing=discord.SeparatorSpacing.small))
                    container.add_item(ui.TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
                    
                    view = ui.LayoutView()
                    view.add_item(container)
                    
                    try:
                        await message.channel.send(view=view)
                    except discord.Forbidden:
                        print(f"{Fore.YELLOW}[WARN]{Style.RESET_ALL} No permission to send in {message.guild.name}")
                    except Exception as e:
                        print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Failed to send mention message: {e}")

            if hasattr(self.bot, 'owner_ids') and self.bot.owner_ids:
                if any(f"<@{oid}>" in message.content or f"<@!{oid}>" in message.content for oid in self.bot.owner_ids):
                    try:
                        await message.add_reaction(Emoji.blue_crown)
                    except:
                        pass
        
        except Exception as e:
            print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Error in on_message event: {e}")

async def setup(bot):
    try:
        await bot.add_cog(MessageEvents(bot))
        print(f"{Fore.GREEN}[SUCCESS]{Style.RESET_ALL} Loaded MessageEvents cog")
    except Exception as e:
        print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Failed to load MessageEvents cog: {e}")
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
