import discord
from discord.ext import commands, tasks
from database import db
import config
from colorama import Fore, Style

class RequirementEvents(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.requirement_sync.start()

    def cog_unload(self):
        self.requirement_sync.cancel()

    @staticmethod
    async def check_eligibility(member: discord.Member, status_req: str, invite_req: int, invite_counts: dict):
        """
        Calculates if a member meets the requirements.
        Returns (has_status, has_invites, status_text_detected, invites_found)
        """
        has_status = False
        text_detected = "NONE"
        
        if status_req:
            for activity in member.activities:
                text = None
                if isinstance(activity, discord.CustomActivity):
                    text = activity.state
                elif isinstance(activity, discord.Activity) and activity.type == discord.ActivityType.custom:
                    text = activity.name
                
                if text:
                    text_detected = text
                    if status_req.lower() in text.lower():
                        has_status = True
                        break
        else:
            has_status = True
            text_detected = "NO_REQ_SET"

        user_invites = invite_counts.get(member.id, 0)
        has_invites = (invite_req <= 0 or user_invites >= invite_req)

        return has_status, has_invites, text_detected, user_invites

    @tasks.loop(minutes=1)
    async def requirement_sync(self):
        """Periodically checks and updates Free Gen role based on status/invites."""
        try:
            await self.bot.wait_until_ready()
            
            guild = self.bot.get_guild(config.GUILD_ID)
            if not guild and self.bot.guilds:
                guild = self.bot.guilds[0]
            
            if not guild: return

            status_req = await db.get_setting("status_req")
            invite_req_str = await db.get_setting("invite_req")
            invite_req = int(invite_req_str) if invite_req_str and invite_req_str.isdigit() else 0
            
            free_role_id = await db.get_setting("fgen_role_id")
            if not free_role_id: return
            
            role = guild.get_role(int(free_role_id))
            if not role: return

            invite_counts = {}
            if guild.me.guild_permissions.manage_guild:
                try:
                    invites = await guild.invites()
                    for inv in invites:
                        if inv.inviter:
                            invite_counts[inv.inviter.id] = invite_counts.get(inv.inviter.id, 0) + inv.uses
                except: pass

            monitored_ids = await db.get_all_monitored()
            if not monitored_ids: return

            print(f"{Fore.CYAN}[SYNC]{Style.RESET_ALL} Processing {len(monitored_ids)} monitored users... (Req: '{status_req}')")
            
            counts = {"added": 0, "removed": 0}
            for user_id in monitored_ids:
                member = guild.get_member(user_id)
                if not member:
                    try: member = await guild.fetch_member(user_id)
                    except:
                        await db.remove_monitor(user_id)
                        continue
                
                if member.bot: continue

                has_status, has_invites, status_text, user_invites = await self.check_eligibility(
                    member, status_req, invite_req, invite_counts
                )

                if has_status and has_invites:
                    if role not in member.roles:
                        try:
                            await member.add_roles(role, reason="Requirement Met")
                            counts["added"] += 1
                            from utils.logger import logger
                            await logger.log_event(self.bot, "ROLE_UPDATE", {
                                "action": "ADD", "user_name": member.name, "user_id": member.id,
                                "user_avatar": member.avatar.url if member.avatar else None,
                                "action_text": "ROLE GRANTED",
                                "reason": f"Status: `{status_req}` Detected\nInvites: `{user_invites}/{invite_req}` Met"
                            })
                        except discord.Forbidden:
                            print(f"{Fore.RED}[HIERARCHY]{Style.RESET_ALL} Cannot give role to {member.name}. Move bot role higher!")
                        except: pass
                else:
                    if role in member.roles:
                        try:
                            loss_reason = ""
                            if not has_status: loss_reason = f"Status mismatch (Required: `{status_req}`, Found: `{status_text}`)"
                            if not has_invites: loss_reason = f"Invite requirements not met (`{user_invites}/{invite_req}`)"
                            
                            await member.remove_roles(role, reason="Requirements lost")
                            counts["removed"] += 1
                            
                            from utils.logger import logger
                            await logger.log_event(self.bot, "ROLE_UPDATE", {
                                "action": "REMOVE", "user_name": member.name, "user_id": member.id,
                                "user_avatar": member.avatar.url if member.avatar else None,
                                "action_text": "ROLE REVOKED", "reason": loss_reason
                            })

                            try:
                                from discord.ui import LayoutView, Container, TextDisplay, Separator
                                dm_view = LayoutView()
                                dm_container = Container(accent_color=None)
                                dm_container.add_item(TextDisplay(f"## {Emoji.lock} FeroX | Access Revoked"))
                                dm_container.add_item(Separator())
                                dm_container.add_item(TextDisplay(
                                    f"Your **Free Gen** access in **{guild.name}** has been removed.\n\n"
                                    f"**Reason:** {loss_reason}\n\n"
                                    f"Please restore your status or invites to regain access."
                                ))
                                dm_container.add_item(Separator(spacing=discord.SeparatorSpacing.small))
                                dm_container.add_item(TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
                                dm_view.add_item(dm_container)
                                await member.send(view=dm_view)
                            except: pass
                        except discord.Forbidden:
                            print(f"{Fore.RED}[HIERARCHY]{Style.RESET_ALL} Cannot remove role from {member.name}. Move bot role higher!")
                        except Exception as e:
                            print(f"{Fore.RED}[SYNC]{Style.RESET_ALL} Revoke failed for {member.name}: {e}")

            if counts["added"] > 0 or counts["removed"] > 0:
                print(f"{Fore.GREEN}[SYNC]{Style.RESET_ALL} Cycle Complete: +{counts['added']}, -{counts['removed']}")
            else:
                print(f"{Fore.YELLOW}[SYNC]{Style.RESET_ALL} Cycle Complete: No changes.")

        except Exception as e:
            print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Requirement sync failed: {e}")

async def setup(bot):
    await bot.add_cog(RequirementEvents(bot))
