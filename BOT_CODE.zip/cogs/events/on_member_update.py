import discord
from discord.ext import commands
from colorama import Fore, Style
from database import db

class MemberUpdateEvents(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        try:
            was_boosting = before.premium_since is not None
            is_now_boosting = after.premium_since is not None

            if was_boosting == is_now_boosting:
                return
                
            bgen_role_id_str = await db.get_setting("bgen_role_id")
            if not bgen_role_id_str or bgen_role_id_str == "0":
                return
                
            bgen_role = after.guild.get_role(int(bgen_role_id_str))
            if not bgen_role:
                return
                
            if is_now_boosting and not was_boosting:    
                if bgen_role not in after.roles:
                    await after.add_roles(bgen_role, reason="Started boosting the server")
                    print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Assigned Booster Gen role to {after.name}")
            
            elif was_boosting and not is_now_boosting:
                if bgen_role in after.roles:
                    await after.remove_roles(bgen_role, reason="Stopped boosting the server")
                    print(f"{Fore.YELLOW}[INFO]{Style.RESET_ALL} Removed Booster Gen role from {after.name}")

        except Exception as e:
            print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Error in on_member_update event: {e}")

async def setup(bot):
    try:
        await bot.add_cog(MemberUpdateEvents(bot))
    except Exception as e:
        print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Failed to load MemberUpdateEvents cog: {e}")
