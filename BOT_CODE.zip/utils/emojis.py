class emoji:

    success = "<a:tickbox_blue:1493631514603159712>"
    error = "<:blue_cross:1493631809756594177>"
    warning = "<:warning:1493632201999519784>"
    info = "<:info:1493632315799109784>"
    loading = "<a:loading:1493632479423234101>"

    back = "<:backward:1493632716791484659>"
    next = "<:forward:1493632767165075659>"
    plus = "<:plus:1493632880885108786>"
    trash = "<:trash:1493632968533479586>"
    gear = "<a:settings:1493633067997466815>"

    shield = "<:shieldc:1493633515751866401>"
    crown = "<:crown:1493633584198713354>"
    lock = "<:lock:1493633704118063314>"
    stats = "<a:stats:1493633869092618392>"
    refresh = "<:refresh:1493633950906847423>"

    free = "<a:disk:1493634377589195034>"
    booster = "<:booster:1493634583135256696>"
    premium = "<a:diamond:1493634720947503305>"
    gold = "<a:gold:1493634856712929301>"
    stock = "<:stock:1493634979866083408>"

    sparkle = "<a:0a_Sparkles3:1493635390827925617>"
    dot = "<a:bluedot:1493635627927867543>"
    arrow = "<:Controller:1493635766084178033>"
    link = "<:links:1493635865241714769>"
    online = "<a:Online:1493636153654378696>"
    offline = "<a:offline:1493636242980470785>"

    ferox_icon = "<:FeroX:1493637006213910721>"
    blue_crown = "<a:bluecrown:1493636775510413476>"
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
