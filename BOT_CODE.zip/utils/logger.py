import discord
from database import db
from datetime import datetime
from utils.emojis import emoji as Emoji
from discord.ui import LayoutView, Container, TextDisplay, Separator
import io

class Logger:
    @staticmethod
    async def log_event(bot, event_type: str, data: dict):
        """
        Sends an advanced Gen-Botstyle log Container to the configured logs channel.
        Types: GEN_SUCCESS, STOCK_REFRESH, ROLE_UPDATE, SYSTEM_ERROR
        """
        logs_cid = await db.get_setting("logs_channel_id")
        if not logs_cid:
            return

        channel = bot.get_channel(int(logs_cid))
        if not channel:
            return

        view = LayoutView()
        container = Container(accent_color=None)
        
        if event_type == "GEN_SUCCESS":
            container.add_item(TextDisplay(f"## {Emoji.sparkle} FeroX | Account Dispatched"))
            container.add_item(Separator())
            container.add_item(TextDisplay(
                f"**Identity:** {data.get('user_name')} (`{data.get('user_id')}`)\n"
                f"**Service:** `{data.get('service').upper()}`\n"
                f"**Tier:** `{data.get('tier').upper()}`\n"
                f"**Location:** <#{data.get('channel_id')}>"
            ))
            container.add_item(Separator(spacing=discord.SeparatorSpacing.small))

        elif event_type == "STOCK_REFRESH":
            container.add_item(TextDisplay(f"## {Emoji.stock} FeroX | Inventory Augmented"))
            container.add_item(Separator())
            container.add_item(TextDisplay(
                f"**Admin:** {data.get('admin_name')}\n"
                f"**Service:** {data.get('service').upper()} ({data.get('tier').upper()})\n"
                f"**Added:** `+{data.get('added')}` Units\n"
                f"**Total Stock:** `{data.get('new_total')}` Units"
            ))
            container.add_item(Separator(spacing=discord.SeparatorSpacing.small))

        elif event_type == "ROLE_UPDATE":
            action = data.get("action")
            container.add_item(TextDisplay(f"## {Emoji.shield if action == 'ADD' else Emoji.lock} FeroX | Requirement Monitoring"))
            container.add_item(Separator())
            container.add_item(TextDisplay(
                f"**Identity:** {data.get('user_name')} (`{data.get('user_id')}`)\n"
                f"**Status:** `{data.get('action_text')}`\n"
                f"**Details:** {data.get('reason')}"
            ))
            container.add_item(Separator(spacing=discord.SeparatorSpacing.small))

        container.add_item(TextDisplay(f"-# {Emoji.crown} Advanced Logging"))
        view.add_item(container)
        
        send_kwargs = {"view": view}

        items = data.get("items")
        if items and isinstance(items, list):
            raw_text = "\n".join(items)
            file_buffer = io.BytesIO(raw_text.encode('utf-8'))
            send_kwargs["file"] = discord.File(file_buffer, filename=f"stock_log_{data.get('service')}_{int(datetime.now().timestamp())}.txt")
        
        try:
            await channel.send(**send_kwargs)
        except Exception as e:
            print(f"Failed to send log: {e}")

logger = Logger()
