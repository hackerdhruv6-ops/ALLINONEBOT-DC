import discord
from discord.ui import (
    View, LayoutView, Container, Section, TextDisplay, Separator, 
    MediaGallery, Thumbnail, ActionRow, Button, Select, Modal, TextInput
)
from database import db
from utils.emojis import emoji as Emoji

class AddStockModal(Modal):
    def __init__(self, service_name: str, tier: str, service_type: str):
        super().__init__(title=f'Add {tier.title()} Stock')
        self.service_name = service_name
        self.tier = tier
        
        placeholders = {
            'account': 'email|password\nemail|password',
            'vcc': 'cardno|exmm|exyy|cvv\ncardno|exmm|exyy|cvv',
            'code': 'REDEEM-CODE-1\nREDEEM-CODE-2'
        }
        
        self.items = TextInput(
            label=f'Enter {service_type.title()}s (One per line)',
            style=discord.TextStyle.paragraph,
            placeholder=placeholders.get(service_type, 'item1\nitem2'),
            required=True,
            min_length=1
        )
        self.add_item(self.items)

    async def on_submit(self, interaction: discord.Interaction):
        items = [item.strip() for item in self.items.value.split('\n') if item.strip()]
        
        if not items:
            await interaction.response.send_message(f"{Emoji.error} No valid items provided.", ephemeral=True)
            return
            
        added = await db.add_stock(self.service_name, self.tier, items)
        
        if added > 0:
            from utils.logger import logger
            services = await db.get_services(self.tier)
            new_total = 0
            for name, count in services:
                if name.lower() == self.service_name.lower():
                    new_total = count
                    break
            
        await logger.log_event(interaction.client, "STOCK_REFRESH", {
            "admin_name": interaction.user.name,
            "service": self.service_name,
            "tier": self.tier,
            "added": added,
            "new_total": new_total,
            "items": items
        })

        ping_enabled = await db.get_setting("restock_ping_enabled", "0")
        if ping_enabled == "1":
            restock_cid = await db.get_setting("restock_channel_id")
            if restock_cid:
                restock_channel = interaction.client.get_channel(int(restock_cid))
            if restock_channel:
                restock_view = LayoutView()
                restock_container = Container(accent_color=None)
                restock_container.add_item(TextDisplay(f"## {Emoji.stock} FeroX | Inventory Secured"))
                restock_container.add_item(Separator())
                restock_container.add_item(TextDisplay(
                    f"**Action:** `{self.tier.upper()} REPLENISHMENT`\n"
                    f"**Service:** {self.service_name.title()}\n"
                    f"**Quantity:** `+{added}` Units\n"
                    f"**Total Stock:** `{new_total}` Units\n"
                    f"**Agent:** {interaction.user.mention}"
                ))
                restock_container.add_item(Separator(spacing=discord.SeparatorSpacing.small))
                restock_container.add_item(TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
                restock_view.add_item(restock_container)
                
                content = None
                restock_role_id = await db.get_setting("restock_role_id")
                if restock_role_id:
                    content = f"<@&{restock_role_id}>"
                
                await restock_channel.send(content=content, view=restock_view)

        container = Container(accent_color=None)
        if added > 0:
            container.add_item(TextDisplay(f"## {Emoji.success} Stock Added Successfully"))
            container.add_item(TextDisplay(f"Added **{added}** items to **{self.service_name}** ({self.tier})."))
        else:
            container.add_item(TextDisplay(f"Service **{self.service_name}** not found in {self.tier} tier."))
        
        container.add_item(Separator(spacing=discord.SeparatorSpacing.small))
        container.add_item(TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))

        view = LayoutView()
        view.add_item(container)
        await interaction.response.send_message(view=view, ephemeral=True)

class ServiceSelect(Select):
    def __init__(self, services: list[tuple[str, str]], action: str, tier: str):
        self.action = action
        self.tier = tier
        self.services_data = services # List of (name,type)
        
        options = [
            discord.SelectOption(label=name.title(), value=name, description=f"Type: {stype.title()}", emoji=Emoji.dot)
            for name, stype in services
        ]
        
        super().__init__(
            placeholder=f"Select a {tier} service to {action}...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        selected_service = self.values[0]
        service_type = 'account'
        for name, stype in self.services_data:
            if name == selected_service:
                service_type = stype
                break
        
        if self.action == "add_stock":
            await interaction.response.send_modal(AddStockModal(selected_service, self.tier, service_type))
        elif self.action == "delete":
            deleted = await db.delete_service(selected_service, self.tier)
            container = Container(accent_color=None)
            if deleted:
                container.add_item(TextDisplay(f"## {Emoji.success} Service Deleted"))
                container.add_item(TextDisplay(f"Successfully deleted {self.tier} service **{selected_service.title()}** and all its stock."))
            else:
                container.add_item(TextDisplay(f"Failed to delete service **{selected_service.title()}**."))
            
            container.add_item(Separator(spacing=discord.SeparatorSpacing.small))
            container.add_item(TextDisplay(f"-# {Emoji.crown} Developed by FeroX Development"))
            
            view = LayoutView()
            view.add_item(container)
            await interaction.response.edit_message(view=view)

class GeneratorView(LayoutView):
    def __init__(self, services: list[str], action: str, tier: str):
        super().__init__(timeout=180)

        container = Container(accent_color=None)
        container.add_item(ActionRow(ServiceSelect(services, action, tier)))
        self.add_item(container)
"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
