import os
import sys
import asyncio
import discord
import time
from datetime import datetime
from discord.ext import commands
from dotenv import load_dotenv
from database import db
import config
from colorama import Fore, Style, init
from api.dashboard_server import app
import uvicorn

if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.detach())

init(autoreset=True)
load_dotenv()

class GeneratorBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.all()
        self.start_time = datetime.now()
        
        super().__init__(
            command_prefix=config.PREFIX,
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        
        try:
            with open('ansi.txt', 'r', encoding='utf-8') as f:
                print(f"{Fore.CYAN}{f.read()}{Style.RESET_ALL}")
        except:
            print(f"{Fore.CYAN}FEROX DEVELOPMENT{Style.RESET_ALL}")

        print(f"{Fore.YELLOW}[SYSTEM]{Style.RESET_ALL} Initializing Core Services...")
        await db.init_db()
        time.sleep(0.5)

        cogs_dir = './cogs'
        for root, dirs, files in os.walk(cogs_dir):
            for filename in files:
                if filename.endswith('.py') and not filename.startswith('__'):
                    relative_path = os.path.relpath(os.path.join(root, filename), '.')
                    ext_path = relative_path.replace(os.sep, '.')[:-3]
                    try:
                        await self.load_extension(ext_path)
                        print(f"  {Fore.GREEN}»{Style.RESET_ALL} Loaded: {ext_path}")
                    except Exception as e:
                        print(f"  {Fore.RED}»{Style.RESET_ALL} Failed: {ext_path} ({e})")
        
        try:
            synced = await self.tree.sync()
            print(f"{Fore.BLUE}[INFO]{Style.RESET_ALL} Synced {len(synced)} command(s)")
        except Exception as e:
            print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Sync Failed: {e}")

        # Start Dashboard
        app.state.bot = self
        config_server = uvicorn.Config(app, host="0.0.0.0", port=config.DASHBOARD_PORT, log_level="error")
        server = uvicorn.Server(config_server)
        asyncio.create_task(server.serve())
        dash_url = getattr(config, 'DASHBOARD_URL', f'http://localhost:{config.DASHBOARD_PORT}')
        print(f"{Fore.MAGENTA}[DASH]{Style.RESET_ALL} Panel active on {dash_url}")

        # Live Status Looop
        asyncio.create_task(self.status_updater())

    async def status_updater(self):
        await self.wait_until_ready()
        print(f"{Fore.YELLOW}[SYSTEM]{Style.RESET_ALL} Status Updater active.")
        while not self.is_closed():
            try:
                status_str = await db.get_setting("bot_status", "online")
                act_type_str = await db.get_setting("bot_activity_type", "watching")
                act_text = await db.get_setting("bot_activity_text", "Generators | FeroX")

                status_map = {"online": discord.Status.online, "idle": discord.Status.idle, "dnd": discord.Status.dnd}
                act_map = {
                    "watching": discord.ActivityType.watching,
                    "playing": discord.ActivityType.playing,
                    "listening": discord.ActivityType.listening,
                    "competing": discord.ActivityType.competing
                }

                status = status_map.get(status_str, discord.Status.online)
                act_type = act_map.get(act_type_str, discord.ActivityType.watching)

                activity = discord.Activity(type=act_type, name=act_text)
                await self.change_presence(status=status, activity=activity)
            except Exception as e:
                print(f"Status Update Error: {e}")
            await asyncio.sleep(60)

    async def on_ready(self):
        print(f"\n{Fore.MAGENTA}╔════════════════════════════════════════════╗")
        print(f"║ Identity:  {self.user.name}#{self.user.discriminator}")
        print(f"║ ID:        {self.user.id}")
        print(f"║ Guilds:    {len(self.guilds)}")
        print(f"║ Status:    Operational")
        print(f"{Fore.MAGENTA}╚════════════════════════════════════════════╝")
        print(f"{Fore.CYAN}Credits: FeroX Development™{Style.RESET_ALL}\n")
        
        activity = discord.Activity(
            type=discord.ActivityType.watching, 
            name="Generators | FeroX"
        )
        await self.change_presence(activity=activity)

    def get_guild_prefix(self, guild_id: int):
        return config.PREFIX

async def run_bot():
    # Built-in server ko background mein start karne ke liye
    port = int(os.environ.get("PORT", 10000))
    config_server = uvicorn.Config(app, host="0.0.0.0", port=port)
    server = uvicorn.Server(config_server)
    asyncio.create_task(server.serve())
    
    # Asli bot ko start karne ke liye config file se token uthayega
    bot = GeneratorBot()
    await bot.start(config.TOKEN)

if __name__ == '__main__':
    asyncio.run(run_bot())