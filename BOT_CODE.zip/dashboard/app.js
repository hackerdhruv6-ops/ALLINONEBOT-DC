let currentTab = 'home';
let userProfile = null;
let allUsers = [];
let userCurrentPage = 1;
const userPageSize = 20;

async function init() {
    try {
        fetch('/api/public/bot-info')
            .then(res => res.json())
            .then(data => {
                const loaderImg = document.getElementById('loader-bot-avatar');
                if (loaderImg && data.avatar) {
                    loaderImg.src = data.avatar;
                    loaderImg.style.opacity = '1';
                    loaderImg.style.transform = 'scale(1)';
                }
            });

        const authRes = await fetch('/api/auth/me');
        if (!authRes.ok) {
            window.location.href = '/api/auth/login';
            return;
        }
        userProfile = await authRes.json();
        updateUIProfile();

        const statusRes = await fetch('/api/setup-status');
        const status = await statusRes.json();

        if (!status.setup_completed) {
            document.getElementById('setup-wizard').classList.remove('hidden');
        }
        await loadWizardData();

        fetchStats();
        await loadStockServices();
        initCustomSelects(); 

        setTimeout(() => {
            const overlay = document.getElementById('loading-overlay');
            if (overlay) {
                overlay.style.opacity = '0';
                setTimeout(() => {
                    overlay.classList.add('hidden');
                    document.getElementById('app').classList.remove('hidden');
                }, 800);
            }
        }, 1000);

    } catch (e) {
        console.error("Initialization Failed", e);
        window.location.href = '/api/auth/login';
    }
}

function updateUIProfile() {
    if (!userProfile) return;
    document.getElementById('user-name').innerText = userProfile.username.toUpperCase();
    document.getElementById('user-avatar').style.backgroundImage = `url('${userProfile.avatar}')`;
    
    const botSidebar = document.getElementById('bot-avatar-sidebar');
    const botMobile = document.getElementById('bot-avatar-mobile');
    
    if (userProfile.bot_avatar) {
        if (botSidebar) {
            botSidebar.src = userProfile.bot_avatar;
            botSidebar.style.opacity = '1';
        }
        if (botMobile) {
            botMobile.src = userProfile.bot_avatar;
            botMobile.style.opacity = '1';
        }
    }
}

function showPage(pageId) {
    document.querySelectorAll('.page-view').forEach(p => p.classList.add('hidden'));
    const target = document.getElementById(`${pageId}-page`);
    if (target) {
        target.classList.remove('hidden');
        target.style.animation = 'none';
        target.offsetHeight; 
        target.style.animation = 'slideUp 0.4s ease-out';
    }

    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.toggle('active', btn.innerText.toLowerCase().includes(pageId));
    });

    const titles = {
        'home': 'SYSTEM OVERVIEW',
        'inventory': 'INVENTORY',
        'users': 'USERS',
        'settings': 'COMMAND CONFIG'
    };

    const titleEl = document.getElementById('current-page-title');
    const fullText = titles[pageId] || 'ACCESSING PROTOCOL...';
    titleEl.innerText = '';
    let i = 0;
    const typeInterval = setInterval(() => {
        if (i < fullText.length) {
            const char = fullText.charAt(i);
            titleEl.innerText += char;
            titleEl.setAttribute('data-text', titleEl.innerText);
            i++;
        } else {
            clearInterval(typeInterval);
        }
    }, 40);

    if (pageId === 'users') loadFreeUsers();
    if (pageId === 'inventory') loadStockServices();

    currentTab = pageId;
    
    closeMobileMenu();
}

async function fetchStats() {
    try {
        const res = await fetch('/api/stats');
        const data = await res.json();

        let free = 0;
        let premium = 0;
        let booster = 0;

        const summaryList = document.getElementById('stock-summary-list');
        if (!summaryList) return;
        summaryList.innerHTML = '';

        for (const [tier, services] of Object.entries(data)) {
            for (const [name, count] of Object.entries(services)) {
                if (tier === 'free') free += count;
                if (tier === 'premium') premium += count;
                if (tier === 'booster') booster += count;

                summaryList.innerHTML += `
            <div class="stock-item-row" style="display: flex; align-items: center; justify-content: space-between; padding: 1rem; border-bottom: 1px solid var(--border);">
                <div style="display: flex; align-items: center; gap: 2rem;">
                    <div class="actions">
                        <span class="badge ${tier}" style="min-width: 80px; text-align: center;">${count} UNITS</span>
                        <a href="javascript:viewStock('${tier}', '${name}')" class="badge" style="background:var(--border); margin-left: 0.5rem; text-decoration:none; color:white;">VIEW</a>
                    </div>
                    <div class="info">
                        <strong style="font-size: 0.9rem; font-family: var(--font-brand); color: var(--text-primary);">${name.toUpperCase()}</strong>
                        <div style="font-size: 0.6rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">PROTOCOL: ${tier.toUpperCase()}</div>
                    </div>
                </div>
            </div>`;
            }
        }

        document.getElementById('stat-free-services').innerText = free;
        document.getElementById('stat-premium-services').innerText = premium;
        document.getElementById('stat-booster-services').innerText = booster;

    } catch (e) {
        console.error("Stats fetch failed");
    }
}

async function loadFreeUsers() {
    const list = document.getElementById('free-users-list');
    const badge = document.getElementById('verified-count-badge');
    if (!list) return;
    list.innerHTML = '<p style="color: var(--text-muted); font-size: 0.7rem; letter-spacing: 2px;">SYNCHRONIZING SECURE RECEPTIONS...</p>';

    try {
        const res = await fetch('/api/guild/free-users');
        allUsers = await res.json();
        userCurrentPage = 1;

        if (badge) badge.innerText = `${allUsers.length} VERIFIED`;

        const totalStat = document.getElementById('stat-total-users');
        if (totalStat) totalStat.innerText = allUsers.length;

        renderUserPage();
    } catch (e) {
        list.innerText = 'ENCRYPTION ERROR: FAILED TO FETCH RECORDS';
    }
}

function renderUserPage() {
    const list = document.getElementById('free-users-list');
    const pageInfo = document.getElementById('page-info');
    if (!list) return;

    const totalPages = Math.ceil(allUsers.length / userPageSize) || 1;
    if (userCurrentPage > totalPages) userCurrentPage = totalPages;
    if (userCurrentPage < 1) userCurrentPage = 1;

    const start = (userCurrentPage - 1) * userPageSize;
    const end = start + userPageSize;
    const paginatedUsers = allUsers.slice(start, end);

    if (pageInfo) pageInfo.innerText = `PAGE ${userCurrentPage} OF ${totalPages}`;

    list.innerHTML = paginatedUsers.map(u => `
        <div class="subscriber-card">
            <div class="avatar" style="background-image: url('${u.avatar}')"></div>
            <div class="id-wrap">
                <strong>${u.name}</strong>
                <span>@${u.username}</span>
            </div>
        </div>
    `).join('') || '<p style="color: var(--text-muted); padding: 2rem;">NO ACTIVE SUBSCRIBERS DETECTED IN MONITOR PROTOCOL</p>';
    
    if (window.lucide) window.lucide.createIcons();
}

function changeUserPage(dir) {
    userCurrentPage += dir;
    renderUserPage();
    document.getElementById('users-page').scrollIntoView({ behavior: 'smooth' });
}

async function loadStockServices() {
    const select = document.getElementById('stock-service-select');
    if (!select) return;
    select.innerHTML = '<option value="">SELECT SERVICE</option>';

    try {
        const tiers = ['free', 'premium', 'booster'];
        for (const t of tiers) {
            const res = await fetch(`/api/services/${t}`);
            const data = await res.json();
            data.services.forEach(s => {
                select.innerHTML += `<option value="${s[0]}|${t}" data-type="${s[1]}">${s[0].toUpperCase()} (${t.toUpperCase()})</option>`;
            });
        }
        
        select.addEventListener('change', (e) => {
            const option = e.target.options[e.target.selectedIndex];
            if (!option || !option.value) return;
            
            const type = option.getAttribute('data-type');
            const textarea = document.getElementById('stock-items');
            const label = document.getElementById('stock-input-label');
            const btn = document.getElementById('add-stock-btn');

            if (type === 'vcc') {
                textarea.placeholder = "card|mm|yy|cvv...";
                label.innerText = "VCC DATA (CARD|MM|YY|CVV)";
                btn.innerText = "ADD VCC ITEMS";
            } else if (type === 'code') {
                textarea.placeholder = "XXXX-XXXX-XXXX...";
                label.innerText = "REDEEM CODE INPUT";
                btn.innerText = "ADD CODES";
            } else if (type === 'minecraft' || type === 'account') {
                textarea.placeholder = "gmail|pass...";
                label.innerText = "ACCOUNT DATA (GMAIL|PASS)";
                btn.innerText = "ADD ACCOUNTS";
            } else {
                textarea.placeholder = "data...";
                label.innerText = "RAW DATA INPUT";
                btn.innerText = "ADD ITEMS";
            }
        });
        initCustomSelects();

    } catch (e) { }
}

async function createService() {
    const name = document.getElementById('new-service-name').value;
    const tier = document.getElementById('new-service-tier').value;
    const type = document.getElementById('new-service-type').value;

    if (!name) return alert("PLEASE ENTER A SERVICE NAME");

    const res = await fetch('/api/services/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, tier, type })
    });

    const data = await res.json();
    if (data.success) {
        alert("SERVICE CREATED SUCCESSFULLY");
        document.getElementById('create-service-form').reset();
        fetchStats();
    }
}

async function addStock() {
    const select = document.getElementById('stock-service-select');
    const serviceString = select.value;
    const itemsRaw = document.getElementById('stock-items').value;

    if (!serviceString || !itemsRaw) return alert("MISSING STOCK DATA");
    
    const option = select.options[select.selectedIndex];
    const type = option.getAttribute('data-type');
    const parts = serviceString.split('|');
    const name = parts[0];
    const tier = parts[1];
    
    const items = itemsRaw.split('\n').filter(i => i.trim() !== '');
    
    for (let item of items) {
        if (type === 'vcc') {
            const segments = item.split('|');
            if (segments.length !== 4) {
                return alert(`INVALID VCC FORMAT AT: ${item}\nEXPECTED: card|mm|yy|cvv`);
            }
            for (let part of segments) {
                if (!/^\d+$/.test(part.trim())) {
                    return alert(`INVALID VCC DATA AT: ${item}\nREASON: All segments must be NUMERIC ONLY.`);
                }
            }
        } else if (type === 'account' || type === 'minecraft') {
            if (!item.includes('|') && !item.includes(':')) {
                return alert(`INVALID ACCOUNT FORMAT AT: ${item}\nEXPECTED: gmail|pass (or email:pass)`);
            }
        }
    }

    const res = await fetch('/api/stock/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ service: name, tier, items })
    });

    const data = await res.json();
    alert(`STOCK UPDATED: ${data.added} ITEMS ADDED`);
    document.getElementById('add-stock-form').reset();
    fetchStats();
}

async function loadSettings() {
    try {
        const res = await fetch('/api/get-settings');
        const data = await res.json();

        if (data.bot_status) document.getElementById('bot-status').value = data.bot_status;
        if (data.bot_activity_type) document.getElementById('bot-activity-type').value = data.bot_activity_type;
        if (data.bot_activity_text) document.getElementById('bot-activity-text').value = data.bot_activity_text;
        
        if (data.status_req) document.getElementById('setting-status-req').value = data.status_req;
        if (data.invite_req) document.getElementById('setting-invite-req').value = data.invite_req;

        if (data.premium_enabled !== undefined) document.getElementById('setting-premium-enabled').value = data.premium_enabled;
        if (data.invite_system_enabled !== undefined) document.getElementById('setting-invite-system-enabled').value = data.invite_system_enabled;
        if (data.restock_ping_enabled !== undefined) document.getElementById('setting-restock-ping-enabled').value = data.restock_ping_enabled;

        if (data.fgen_channel_id) document.getElementById('setting-fgen-channel').value = data.fgen_channel_id;
        if (data.fgen_role_id) document.getElementById('setting-fgen-role').value = data.fgen_role_id;
        if (data.pgen_channel_id) document.getElementById('setting-pgen-channel').value = data.pgen_channel_id;
        if (data.pgen_role_id) document.getElementById('setting-pgen-role').value = data.pgen_role_id;
        if (data.bgen_channel_id) document.getElementById('setting-bgen-channel').value = data.bgen_channel_id;
        if (data.bgen_role_id) document.getElementById('setting-bgen-role').value = data.bgen_role_id;
        if (data.vouch_channel_id) document.getElementById('setting-vouch-channel').value = data.vouch_channel_id;
        if (data.logs_channel_id) document.getElementById('setting-logs-channel').value = data.logs_channel_id;
        if (data.restock_channel_id) document.getElementById('setting-restock-channel').value = data.restock_channel_id;
        if (data.restock_role_id) document.getElementById('setting-restock-role').value = data.restock_role_id;

        if (data.fgen_cooldown) document.getElementById('setting-fgen-cooldown').value = data.fgen_cooldown;
        if (data.pgen_cooldown) document.getElementById('setting-pgen-cooldown').value = data.pgen_cooldown;
        if (data.bgen_cooldown) document.getElementById('setting-bgen-cooldown').value = data.bgen_cooldown;

    } catch (e) { console.error("Load Settings Failed", e); }
}

async function saveSettings() {
    const status = document.getElementById('bot-status').value;
    const type = document.getElementById('bot-activity-type').value;
    const text = document.getElementById('bot-activity-text').value;

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            bot_status: status,
            bot_activity_type: type,
            bot_activity_text: text
        })
    });
    alert("SYSTEM SETTINGS UPDATED");
}

async function saveRequirements() {
    const sreq = document.getElementById('setting-status-req').value;
    const ireq = document.getElementById('setting-invite-req').value;

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            status_req: sreq,
            invite_req: ireq
        })
    });
    alert("REQUIREMENTS PHASE COMMITTED");
}

async function saveCooldowns() {
    const fgen = document.getElementById('setting-fgen-cooldown').value;
    const pgen = document.getElementById('setting-pgen-cooldown').value;
    const bgen = document.getElementById('setting-bgen-cooldown').value;

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            fgen_cooldown: fgen,
            pgen_cooldown: pgen,
            bgen_cooldown: bgen
        })
    });
    alert("GENERATOR PERFORMANCE COMMITTED");
}

async function saveFeatures() {
    const prem = document.getElementById('setting-premium-enabled').value;
    const inv = document.getElementById('setting-invite-system-enabled').value;
    const pings = document.getElementById('setting-restock-ping-enabled').value;

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            premium_enabled: parseInt(prem),
            invite_system_enabled: parseInt(inv),
            restock_ping_enabled: parseInt(pings)
        })
    });
    alert("FEATURE MODULES COMMITTED");
}

async function saveMapping() {
    const payload = {
        fgen_channel_id: document.getElementById('setting-fgen-channel').value,
        fgen_role_id: document.getElementById('setting-fgen-role').value,
        pgen_channel_id: document.getElementById('setting-pgen-channel').value,
        pgen_role_id: document.getElementById('setting-pgen-role').value,
        bgen_channel_id: document.getElementById('setting-bgen-channel').value,
        bgen_role_id: document.getElementById('setting-bgen-role').value,
        vouch_channel_id: document.getElementById('setting-vouch-channel').value,
        logs_channel_id: document.getElementById('setting-logs-channel').value,
        restock_channel_id: document.getElementById('setting-restock-channel').value,
        restock_role_id: document.getElementById('setting-restock-role').value
    };

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    alert("SYSTEM_MAPPING_PHASE_FINALIZED");
}

async function loadWizardData() {
    try {
        const [cRes, rRes] = await Promise.all([
            fetch('/api/guild/channels'),
            fetch('/api/guild/roles')
        ]);
        const channels = await cRes.json();
        const roles = await rRes.json();

        const cSelects = ['setup-fgen-channel', 'setup-pgen-channel', 'setup-bgen-channel', 'setup-vouch-channel', 'setup-logs-channel'];
        const rSelects = ['setup-fgen-role', 'setup-pgen-role', 'setup-bgen-role'];

        const cSettings = ['setting-fgen-channel', 'setting-pgen-channel', 'setting-bgen-channel', 'setting-vouch-channel', 'setting-logs-channel', 'setting-restock-channel'];
        const rSettings = ['setting-fgen-role', 'setting-pgen-role', 'setting-bgen-role', 'setting-restock-role'];

        cSelects.concat(cSettings).forEach(id => {
            const el = document.getElementById(id);
            if (el) el.innerHTML = channels.map(c => `<option value="${c.id}">#${c.name}</option>`).join('');
        });

        rSelects.concat(rSettings).forEach(id => {
            const el = document.getElementById(id);
            if (el) el.innerHTML = roles.map(r => `<option value="${r.id}">${r.name}</option>`).join('');
        });

        await loadSettings();
    } catch (e) { console.error("Load Wizard Failed", e); }
}

async function submitSetup() {
    const cfg = {
        fgen_channel_id: document.getElementById('setup-fgen-channel').value,
        fgen_role_id: document.getElementById('setup-fgen-role').value,
        pgen_channel_id: document.getElementById('setup-pgen-channel').value,
        pgen_role_id: document.getElementById('setup-pgen-role').value,
        bgen_channel_id: document.getElementById('setup-bgen-channel').value,
        bgen_role_id: document.getElementById('setup-bgen-role').value,
        vouch_channel_id: document.getElementById('setup-vouch-channel').value,
        logs_channel_id: document.getElementById('setup-logs-channel').value
    };

    if (Object.values(cfg).some(v => !v)) return alert("ALL_PROTOCOLS_REQUIRED");

    await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg)
    });
    
    document.getElementById('setup-wizard').classList.add('hidden');
    init();
}

function logout() {
    document.cookie = "ferox_auth=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    window.location.href = '/api/auth/login';
}

init();
async function closeStockView() {
    document.getElementById('stock-view-modal').classList.add('hidden');
}

async function viewStock(tier, service) {
    document.getElementById('stock-view-modal').classList.remove('hidden');
    document.getElementById('stock-view-title').innerText = `${service.toUpperCase()} (${tier.toUpperCase()})`;
    const contentBox = document.getElementById('stock-view-content');
    
    document.getElementById('stock-view-tier').value = tier;
    document.getElementById('stock-view-service').value = service;
    
    contentBox.innerText = "Loading securely...";
    
    try {
        const res = await fetch(`/api/stock/view/${tier}/${service}`);
        const data = await res.json();
        
        if (data.items && data.items.length > 0) {
            contentBox.innerText = data.items.join('\n');
        } else {
            contentBox.innerText = "NO CREDENTIALS LOCATED FOR THIS PROTOCOL.";
        }
    } catch (e) {
        contentBox.innerText = "ERROR: Failed to fetch encrypted payload.";
    }
}

function toggleMobileMenu() {
    const sidebar = document.getElementById('main-sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (sidebar) sidebar.classList.toggle('mobile-active');
    if (backdrop) backdrop.classList.toggle('active');
}

function closeMobileMenu() {
    const sidebar = document.getElementById('main-sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (sidebar) sidebar.classList.remove('mobile-active');
    if (backdrop) backdrop.classList.remove('active');
}

document.addEventListener('DOMContentLoaded', () => {
    if(typeof lucide !== 'undefined') lucide.createIcons();
    
    window.addEventListener('click', (e) => {
        const wrappers = document.querySelectorAll('.custom-select-wrapper');
        wrappers.forEach(w => {
            if (!w.contains(e.target)) w.classList.remove('open');
        });
    });
});

function initCustomSelects() {
    const selects = document.querySelectorAll('select:not(.custom-select-native)');
    selects.forEach(select => {
        const oldWrapper = select.closest('.custom-select-wrapper');
        if (oldWrapper) {
            return;
        }

        const wrapper = document.createElement('div');
        wrapper.className = 'custom-select-wrapper';
        select.parentNode.insertBefore(wrapper, select);
        wrapper.appendChild(select);
        
        select.classList.add('custom-select-native');

        const trigger = document.createElement('div');
        trigger.className = 'custom-select-trigger';
        trigger.innerText = select.options[select.selectedIndex]?.text || "SELECT OPTION";
        wrapper.appendChild(trigger);

        const optionsDiv = document.createElement('div');
        optionsDiv.className = 'custom-options';
        
        const buildOptions = () => {
            optionsDiv.innerHTML = '';
            Array.from(select.options).forEach((opt, idx) => {
                const o = document.createElement('div');
                o.className = 'custom-option';
                if (idx === select.selectedIndex) o.classList.add('selected');
                o.innerText = opt.text;
                o.onclick = () => {
                    select.selectedIndex = idx;
                    trigger.innerText = opt.text;
                    Array.from(optionsDiv.children).forEach(child => child.classList.remove('selected'));
                    o.classList.add('selected');
                    wrapper.classList.remove('open');
                    select.dispatchEvent(new Event('change'));
                };
                optionsDiv.appendChild(o);
            });
        };

        buildOptions();
        wrapper.appendChild(optionsDiv);

        trigger.onclick = (e) => {
            e.stopPropagation();
            const isOpen = wrapper.classList.contains('open');
            document.querySelectorAll('.custom-select-wrapper').forEach(w => w.classList.remove('open'));
            if (!isOpen) {
                buildOptions();
                wrapper.classList.add('open');
            }
        };
    });
}
